"""Paired, dataset-stratified resampling of held-out observations.

The same sampled rows enter the clean and altered conditions and all methods.
Intervals describe test-case composition conditional on stored predictions.
They do not include the variability of refitting models on new training sets.
"""
from pathlib import Path
import numpy as np
import pandas as pd

TRIALS = 5000
RANDOM_SEED = 20261119
ROOT = Path(__file__).resolve().parent/'results'


def main():
    obs = pd.read_csv(ROOT/'by_observation.csv')
    methods = list(obs.method.unique())
    rng = np.random.default_rng(RANDOM_SEED)
    diff_draws = np.zeros((TRIALS,len(methods),2))
    diff_point = np.zeros((len(methods),2))
    for dataset in ['Iris','Wine','Seeds','Penguins']:
        sample = obs[obs.dataset==dataset]
        # Average both conditions before sampling. Folds, repetitions and
        # permutations are already averaged within each test observation.
        grouped = sample.groupby(['row_index','method'])[['accuracy','brier']].mean()
        values = np.stack([grouped.xs(method,level='method').sort_index().values for method in methods],axis=1)
        diff = values[:,[methods.index('RSAR')],:] - values
        diff_point += diff.mean(axis=0)/4
        n = len(values)
        for start in range(0,TRIALS,100):
            idx = rng.integers(0,n,(min(100,TRIALS-start),n))
            diff_draws[start:start+len(idx)] += diff[idx].mean(axis=1)/4
    lo, hi = np.quantile(diff_draws,[.025,.975],axis=0)
    records=[]
    for j,m in enumerate(methods):
        for k,metric in enumerate(['accuracy_points','brier']):
            scale = 100 if k==0 else 1
            records.append([m,metric,scale*diff_point[j,k],scale*lo[j,k],scale*hi[j,k]])
    pd.DataFrame(records,columns=['reference','metric','proposed_minus_reference','lower','upper']).to_csv(ROOT/'paired_intervals.csv',index=False)


if __name__=='__main__':
    main()
