import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

if __name__=='__main__':
    env = dict(os.environ)
    env['OPENBLAS_NUM_THREADS'] = '1'
    steps = [
        ('verify.py',),
        ('fusion.py',),
        ('benchmark.py',),
        ('paired.py',),
        ('certificate.py','--out','results'),
        ('tables.py',),
        ('figures.py',),
    ]
    for step in steps:
        print('Running',*step,flush=True)
        subprocess.run([sys.executable,*step],cwd=ROOT,env=env,check=True)
