"""Verify the rotor decision and tabulate the sensitivity paths.
Python 3.10+, mpmath, numpy, scipy. Run in a writable folder.
Source data: Lu and Xiao, Applied Intelligence 54 (2024), Table 9.
"""
from pathlib import Path
from functools import reduce
from operator import mul
import csv
import math
import numpy as np
from mpmath import iv
from scipy.optimize import brentq, minimize_scalar

# S0 normal, S1 unbalance, S2 misalignment, S3 loose pedestal, full frame.
RAW=[['.06','.68','.02','.04','.20'],['.02','0','.79','.05','.14'],['.02','.58','.16','.04','.20']]
METHODS=['RSAR','Tang','Absolute loss + source-specific retention','Relative loss + fixed retention']
iv.dps=35

def prod(xs):
    return reduce(mul,xs,1)

def make_evaluator(source,interval=False):
    scalar=iv.mpf if interval else float
    sqrt=iv.sqrt if interval else math.sqrt
    x=[[scalar(a) for a in row] for row in RAW]
    pair=x[source][1]+x[source][2]
    def gram(u,v):
        # Jaccard kernel for a four-singleton/full-frame focal family.
        return sum(a*b for a,b in zip(u[:4],v[:4]))+u[4]*v[4]+(u[4]*sum(v[:4])+v[4]*sum(u[:4]))/4
    def evaluate(t,method):
        x[source][1],x[source][2]=pair*(1-t),pair*t
        g=[gram(y,y) for y in x]
        a=gram(x[0],x[1])/sqrt(g[0]*g[1])
        b=gram(x[0],x[2])/sqrt(g[0]*g[2])
        c=gram(x[1],x[2])/sqrt(g[1]*g[2])
        s=[a+b,a+c,b+c]
        if method in [METHODS[0],METHODS[3]]:
            mu=[(a/s[1]+b/s[2])/2,(a/s[0]+c/s[2])/2,(b/s[0]+c/s[1])/2]
            weights=[h*m for h,m in zip(s,mu)]
        else:
            weights=[h*h for h in s]
        weights=[h/sum(weights) for h in weights]
        mean=[sum(w*y[k] for w,y in zip(weights,x)) for k in range(5)]
        retain=[h/2 for h in s] if method in [METHODS[0],METHODS[2]] else [scalar('0.5')]*3
        adjusted=[[v*y[k]+(1-v)*mean[k] for k in range(5)] for y,v in zip(x,retain)]
        ignorance=prod(y[4] for y in adjusted)
        # Conjunctive singleton mass from all tuples consistent with k,
        # excluding the tuple consisting only of full frames.
        mass=[prod(y[k]+y[4] for y in adjusted)-ignorance for k in range(4)]
        # Use the margin form separately for interval certification.
        other=ignorance+mass[0]+mass[2]+mass[3]
        return mass[1],other
    return evaluate

def certify(method,left,right,level,gt=True):
    # Input endpoints are exact decimal rationals enclosed by outward-rounded
    # iv.mpf values. Each dyadic subcell uses this same domain parametrization.
    f=make_evaluator(1,True)
    left,right,level=map(iv.mpf,[left,right,level])
    todo=[(0,0)]
    certified=0
    max_depth=0
    while todo:
        j,k=todo.pop()
        subcell=iv.mpf([j,j+1])/(2**k)
        t=left+(right-left)*subcell
        yes,other=f(t,method)
        # Exact normalization denominator is positive: all inputs carry
        # strictly positive full-frame mass throughout this path.
        margin=(1-level)*yes-level*other
        if (margin.a>0 if gt else margin.b<0):
            certified+=1
            max_depth=max(k,max_depth)
        else:
            if k>=28:
                raise ValueError(f'Inconclusive at cell {j}/2^{k}.')
            todo.extend([(2*j,k+1),(2*j+1,k+1)])
    return certified,max_depth

def main(out):
    out.mkdir(exist_ok=True,parents=True)
    grid=np.linspace(0,1,501)
    rows=[]
    landmarks=[]
    for source in range(3):
        f=make_evaluator(source)
        for j,method in enumerate(METHODS):
            def score(t):
                yes,other=f(t,method)
                return yes/(yes+other)
            ys=[score(t) for t in grid]
            rows.extend(dict(sensor=source+1,method=method,t=t,mass_unbalance=y) for t,y in zip(grid,ys))
            if source==1:
                if j==0:
                    res=minimize_scalar(score,bounds=(.7,.85),method='bounded',options={'xatol':1e-13})
                    print('Feasible near-minimum, t and mass:',res.x,res.fun)
                    landmarks.append(('RSAR','numerical minimum',res.x,res.fun))
                if j==1:
                    cross=brentq(lambda t:score(t)-.8,.808,.810)
                    print('Tang numerical crossing:',cross)
                    landmarks.append(('Tang','threshold crossing',cross,score(cross)))
    with (out/'rotor_landmarks.csv').open('w',newline='') as file:
        writer=csv.writer(file)
        writer.writerow(['method','quantity','t','mass_unbalance'])
        writer.writerows(landmarks)
    with (out/'rotor_paths.csv').open('w',newline='') as file:
        w=csv.DictWriter(file,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
    tests=[('RSAR','0','1','0.8314',True),('Tang','0','0.808','0.80',True),('Tang','0.810','1','0.80',False)]
    result=[]
    for method,left,right,threshold,gt in tests:
        cells,depth=certify(method,left,right,threshold,gt)
        sentence=f'{method} on [{left},{right}]: mass {">" if gt else "<"} {threshold}; {cells} certified subintervals, maximum depth {depth}.'
        result.append(sentence);print(sentence,flush=True)
    # Upper bound on the minimum via one feasible point, enclosed arithmetically.
    y,o=make_evaluator(1,True)(iv.mpf('.78'),'RSAR')
    h=y/(y+o)
    assert h.b<iv.mpf('0.83147')
    result.append('At t=0.78 the RSAR mass is below 0.83147, giving an upper bound on the minimum.')
    (out/'interval_verification.txt').write_text('\n'.join(result)+'\n')

if __name__=='__main__':
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument('--out',type=Path,default=Path('.'))
    main(parser.parse_args().out)
