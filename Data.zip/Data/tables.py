from pathlib import Path
import argparse
import pandas as pd
from fusion import FIVE

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'results'
METHODS=['Dempster','Arithmetic mean','Murphy','Deng','Han','Tang','Lu and Xiao','Xi (2n)','Xi (n)','Huang and Deng','RSAR']
TITLES={'Deng':'Deng et al.','Han':'Han et al.','Tang':'Tang et al. (2023)','Xi (2n)':'Xi et al., $2n$','Xi (n)':'Xi et al., $n$'}
WEIGHTS=['Uniform pool','Strength pool','Squared-strength pool','RSAR']
LOSS=['Equal','$\\ns_i$','$\\ns_i^2$','$\\ns_i\\mu_i$']
NEW=r' \\'
def name(x):
    return TITLES.get(x,x)

def table(out,stem,caption,label,spec,header,body,sep=4):
    doc=[r'\begin{table}[!htbp]',r'\caption{'+caption+'}',r'\label{'+label+'}',r'\centering\small',
         r'\setlength{\tabcolsep}{'+str(sep)+'pt}',r'\begin{tabular}{'+spec+'}',r'\toprule',*header,r'\midrule',*body,r'\bottomrule',r'\end{tabular}',r'\end{table}']
    (out/(stem+'.tex')).write_text('\n'.join(doc)+'\n')

def main(out):
    out.mkdir(parents=True,exist_ok=True)
    cases=pd.read_csv(DATA/'case_results.csv').set_index(['case','q','method'])
    coef=pd.read_csv(DATA/'source_coefficients.csv')
    cl=pd.read_csv(DATA/'classification.csv').set_index(['dataset','setting','method'])
    avg=cl[['accuracy','brier']].groupby('method').mean()
    clean=cl[['accuracy','brier']].groupby(['setting','method']).mean()
    subset=coef[(coef['case']=='Five')&(coef.q==5)].set_index('source')
    rows=[]
    for i in range(5):
        source=subset.loc[i+1]
        parts=[f'$S_{i+1}$']+[f'{x:.2f}' for x in FIVE[i,[1,2,4,5]]]+[f'{source[key]:.4f}' for key in ['strength','mu','weight','retention']]
        rows.append(' & '.join(parts)+NEW)
    table(out,'tab_sources','Five-source inputs from Tang et al.\\ \\cite{Tang} and the quantities obtained from all five reports. $AC$ denotes $\\{A,C\\}$.','tab:sources','lrrrrrrrr',
          [r'Source & $m(A)$ & $m(B)$ & $m(C)$ & $m(AC)$ & $\ns_i$ & $\mu_i$ & $\omega_i$ & $\rho_i$'+NEW],rows,3.2)
    rows=[]
    for m in METHODS:
        if m.startswith('Xi'):continue
        f=cases.loc['Five',5,m];r=cases.loc['Rotor',3,m]
        rows.append(' & '.join([name(m),f'{f.target_mass:.4f}',f'{f.target_BetP:.4f}',
                                 f'{r.target_mass:.4f}',f'{r.target_BetP:.4f}', 'Yes' if r.target_mass>.8 else 'No'])+NEW)
    table(out,'tab_cases',r'Matched-input results for the five-source target example and the published rotor diagnosis. The 0.8 threshold applies to $m(U)$ alone.',
          'tab:cases','lrrrrc',[r' & \multicolumn{2}{c}{Five sources} & \multicolumn{3}{c}{Rotor diagnosis}'+NEW,
            r'\cmidrule(lr){2-3}\cmidrule(lr){4-6}',r'Method & $m(A)$ & $\bet(A)$ & $m(U)$ & $\bet(U)$ & $m(U)>0.8$'+NEW],rows,4)
    rows=[]
    for a,fixed,adaptive in [('Absolute','Tang','Squared-strength pool'),('Relative','Relative loss, fixed retention','RSAR')]:
        rows.append(' & '.join([a,f"{cases.loc[('Rotor',3,fixed),'target_mass']:.4f}",f"{cases.loc[('Rotor',3,adaptive),'target_mass']:.4f}"])+NEW)
    table(out,'tab_crossed','Mass assigned to rotor unbalance when reference weighting and retention are varied independently.','tab:cross','lcc',
          ['Removal loss & Fixed retention $1/2$ & Source-specific retention $\\rho_i$'+NEW],rows,6)
    rows=[]
    for m in METHODS:
        vals=[]
        for row in [clean.loc[('clean',m)],clean.loc[('one_source_label_swap',m)],avg.loc[m]]:
            vals.extend([f'{100*row.accuracy:.2f}',f'{row.brier:.4f}'])
        if m=='RSAR': rows.append(r'\midrule')
        rows.append(' & '.join([name(m),*vals])+NEW)
    table(out,'tab_summary','Out-of-fold performance. Each condition gives equal weight to the four datasets. The overall mean weights both conditions equally. Accuracy is expressed in percent.','tab:summary','lrrrrrr',
          [r' & \multicolumn{2}{c}{Unmodified} & \multicolumn{2}{c}{One faulty source} & \multicolumn{2}{c}{Overall mean}'+NEW,r'\cmidrule(lr){2-3}\cmidrule(lr){4-5}\cmidrule(lr){6-7}',
           'Method & Acc. & Brier & Acc. & Brier & Acc. & Brier'+NEW],rows,4.5)
    rows=[]
    for m,weight in zip(WEIGHTS,LOSS):
        rows.append(' & '.join([weight,f"{cases.loc[('Five',5,m),'target_BetP']:.4f}",f"{cases.loc[('Rotor',3,m),'target_mass']:.4f}",
                               f'{avg.loc[m,"accuracy"]*100:.2f}',f'{avg.loc[m,"brier"]:.4f}'])+NEW)
    table(out,'tab_weights','Reference-weight ablation with the same source-specific retention in all rows. Classification scores average the eight dataset--condition pairs.','tab:weights','lrrrr',
          [r'Reference weight & Five, $\bet(A)$ & Rotor, $m(U)$ & Acc. (\%) & Brier'+NEW],rows,6)
    for metric in ('accuracy','brier'):
        rows=[]
        for m in METHODS:
            parts=[name(m)]
            for dat in ('Iris','Wine','Seeds','Penguins'):
                for condition in ('clean','one_source_label_swap'):
                    val=cl.loc[(dat,condition,m),metric]
                    parts.append(f'{100*val:.2f}' if metric=='accuracy' else f'{val:.4f}')
            if m=='RSAR':rows.append(r'\midrule')
            rows.append(' & '.join(parts)+NEW)
        title='Out-of-fold accuracy in percent' if metric=='accuracy' else 'Out-of-fold multiclass Brier score'
        table(out,'tab_'+metric,title+' for unmodified inputs (C) and a single source with permuted output labels (F).',
              'tab:'+metric,'lrrrrrrrr',[r' & \multicolumn{2}{c}{Iris} & \multicolumn{2}{c}{Wine} & \multicolumn{2}{c}{Seeds} & \multicolumn{2}{c}{Penguins}'+NEW,
              r'\cmidrule(lr){2-3}\cmidrule(lr){4-5}\cmidrule(lr){6-7}\cmidrule(lr){8-9}','Method & C & F & C & F & C & F & C & F'+NEW],rows,2.6)
if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out',type=Path,default=ROOT/'tables')
    main(parser.parse_args().out)
