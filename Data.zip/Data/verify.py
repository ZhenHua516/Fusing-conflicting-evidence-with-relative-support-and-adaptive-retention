import numpy as np
import benchmark as bench
import fusion as ref
from certificate import make_evaluator


def xi_scalar(p,power):
    n=len(p)
    indicators=np.zeros((3,n))
    for i,x in enumerate(p):
        for y in p:
            indicators[0,i]+=np.linalg.norm(x-y)/np.sqrt(2)
            indicators[1,i]+=sum(xx*np.log2(xx/yy) for xx,yy in zip(x,y))
        indicators[2,i]=-sum(xx*np.log2(xx) for xx in x)
    total=np.sum([row/np.linalg.norm(row) for row in indicators if np.linalg.norm(row)>1e-14],axis=0)
    importance=np.array([sum(zj/(zj+zi) for zj in total) for zi in total])
    pool=ref.normalize(importance**power)@p
    singleton=ref.embed([pool],[1,2,4],3)[0]
    return ref.betp(ref.repeated(singleton,n))


def check():
    rng=np.random.default_rng(707)
    for n in (2,3,4,7,13):
        for _ in range(6):
            p=rng.dirichlet([.35,1,1.5],size=n)
            masses=ref.embed(p,[1,2,4],3)
            vectorized=dict(zip(bench.RULES,bench.fuse_many(p[None,:,:])[0]))
            scalar=ref.case_methods(masses)
            for method,pred in vectorized.items():
                if method.startswith('Xi'):
                    expected=xi_scalar(p,n if method=='Xi (n)' else 2*n)
                else:
                    expected=ref.betp(scalar[method])
                np.testing.assert_allclose(pred,expected,rtol=0,atol=2e-12)

    # Closed forms on the five-source focal family and on the rotor.
    for n in range(2,6):
        masses=ref.FIVE[:n]
        _,_,_,w,rho=ref.network(masses)
        a,b,c,ac=ref.adjust(masses,w,rho)[:,[1,2,4,5]].T
        raw=np.array([np.prod(a+ac)-np.prod(ac),np.prod(b),np.prod(c+ac)-np.prod(ac),np.prod(ac)])
        np.testing.assert_allclose(ref.proposed(masses)[[1,2,4,5]],ref.normalize(raw),rtol=0,atol=1e-13)
    for t in (0.,.78,.81,1.):
        masses=ref.ROTOR.copy()
        masses[1,[2,4]]=[.79*(1-t),.79*t]
        for k in ['RSAR','Tang']:
            a,b=make_evaluator(1)(t,k)
            assert abs(ref.case_methods(masses)[k][2]-a/(a+b))<2e-14

    # Degenerate graphs, exact sharing and the single-source extension.
    mutually_disjoint=ref.embed(np.eye(3),[1,2,4],3)
    _,ns,mu,w,rho=ref.network(mutually_disjoint)
    np.testing.assert_array_equal(ns,0)
    np.testing.assert_array_equal(mu,0)
    np.testing.assert_array_equal(rho,0)
    np.testing.assert_allclose(w,1/3)
    np.testing.assert_allclose(ref.betp(ref.proposed(mutually_disjoint)),[1/3]*3)
    composite=ref.embed([[1.],[1.],[1.]],[5],3)
    np.testing.assert_allclose(ref.proposed(composite),composite[0])
    np.testing.assert_array_equal(ref.proposed(ref.FIVE[:1]),ref.FIVE[0])
    singleton_outlier=ref.embed([[1,0],[1,0],[0,1]],[1,2],2)
    np.testing.assert_allclose(ref.proposed(singleton_outlier),singleton_outlier[0])

    assert abs(ref.case_methods(ref.LIN)['Tang'][1]-.9735)<.00005
    np.testing.assert_allclose(ref.case_methods(ref.ROTOR)['Lu and Xiao'][[1,2,4,8]],
                               [.0027,.9424,.0518,.0031],rtol=0,atol=.00015)
    first=np.array([.49,.21,.30])
    assert abs(1/(1+np.exp((first*np.log2(first)).sum()))-.8173)<.00005
    totals=np.array([1.1465,2.1873,1.1339])
    f=(totals[None,:]/(totals[None,:]+totals[:,None])).sum(1)
    np.testing.assert_allclose(ref.normalize(f**3),[.4196,.1546,.4258],rtol=0,atol=.00006)
    print('All scalar, closed-form, boundary and published-example checks passed.')


if __name__=='__main__':
    check()
