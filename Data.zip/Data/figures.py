from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
OUTPUT = ROOT/'graphics'
RESULTS = ROOT/'results'
TEAL, INK, RUST, GRAY = '#006966','#172e40','#ac481e','#53626b'
PALE, LINE = '#eaf5f2','#c1d0d4'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8.1,'axes.labelsize':8.2,
                     'xtick.labelsize':7.6,'ytick.labelsize':7.6,'text.color':INK,
                     'axes.labelcolor':INK,'xtick.color':INK,'ytick.color':INK,
                     'axes.edgecolor':'#8f9da1','axes.linewidth':.65,'lines.linewidth':1.7,
                     'pdf.fonttype':42,'ps.fonttype':42,'svg.fonttype':'none',
                     'mathtext.fontset':'dejavusans','legend.frameon':False})


def save(fig,name):
    OUTPUT.mkdir(exist_ok=True)
    for extension in ('pdf','svg','png'):
        fig.savefig(OUTPUT/(name+'.'+extension),dpi=600,facecolor='white')
    plt.close(fig)


def tidy(ax):
    ax.spines[['top','right']].set_visible(False)
    ax.tick_params(length=2.4,width=.6,pad=3)
    ax.grid(axis='y',lw=.55,color='#d7e0e1',zorder=0)
    ax.set_axisbelow(True)


def workflow():
    fig,ax=plt.subplots(figsize=(4.78,3.04))
    fig.subplots_adjust(0,0,1,1)
    ax.set(xlim=(0,10),ylim=(0,7));ax.axis('off')
    def box(cx,cy,w,h,heading,equation,color,fill='white'):
        ax.add_patch(FancyBboxPatch((cx-w/2,cy-h/2),w,h,boxstyle='round,pad=0.025,rounding_size=.1',
                                    ec=color,fc=fill,lw=.9,zorder=2))
        ax.text(cx,cy+.17,heading,ha='center',va='center',fontsize=8.5,fontweight='semibold',color=color)
        ax.text(cx,cy-.225,equation,ha='center',va='center',fontsize=8.35,color=INK)
    def connector(path):
        for (x,y),(xx,yy) in zip(path[:-2],path[1:-1]):
            ax.plot([x,xx],[y,yy],lw=.9,color=GRAY,zorder=0)
        ax.add_patch(FancyArrowPatch(path[-2],path[-1],arrowstyle='-|>',mutation_scale=8,lw=.9,color=GRAY,zorder=1,
                                    shrinkA=0,shrinkB=1))
    box(5,6.2,6.35,1.05,'Pairwise evidence correlation',r'$m_1,\ldots,m_n\ \longrightarrow\ R\ \longrightarrow\ \mathrm{NS}_i=\sum_{j\ne i}r_{ij}$',INK,'#f4f7f8')
    box(2.53,4.31,4.71,1.27,'Weight in the reference',r'$\mu_i\ \longrightarrow\ \omega_i\ \propto\ \mathrm{NS}_i\,\mu_i$',TEAL,PALE)
    box(7.47,4.31,4.71,1.27,'Retention by each source',r'$\rho_i=\mathrm{NS}_i/(n-1)$',RUST,'#fcf2eb')
    connector([(5,5.66),(5,5.33),(2.53,5.33),(2.53,4.99)])
    connector([(5,5.33),(7.47,5.33),(7.47,4.99)])
    connector([(2.53,3.64),(2.53,3.14),(4.04,3.14),(4.04,2.87)])
    connector([(7.47,3.64),(7.47,3.14),(5.96,3.14),(5.96,2.87)])
    box(5,2.29,7.85,1.08,'Adjustment on the original focal sets',
        r'$\bar m=\sum_j\omega_jm_j$       $\widetilde m_i=\rho_i m_i+(1-\rho_i)\bar m$',INK,'#f4f7f8')
    connector([(5,1.72),(5,1.26)])
    box(5,.68,6.35,1.04,'Dempster combination',r'$m_\star=\widetilde m_1\oplus\cdots\oplus\widetilde m_n$',INK)
    save(fig,'fig1_workflow')


def five():
    df=pd.read_csv(RESULTS/'correlations.csv')
    matrix=df[(df['case']=='Five')&(df.q==5)].pivot(index='i',columns='j',values='correlation')
    case=pd.read_csv(RESULTS/'case_results.csv')
    lines=case[(case['case']=='Five')&(case.method=='RSAR')].sort_values('q')
    fig,(left,right)=plt.subplots(1,2,figsize=(4.78,2.3),gridspec_kw={'width_ratios':[1.01,1.08]})
    fig.subplots_adjust(.079,.205,.982,.83,wspace=.42)
    cm=LinearSegmentedColormap.from_list('Agreement',['#f3f8f6','#b9dcd5','#267f78','#075652'])
    left.imshow(matrix,vmin=0,vmax=1,cmap=cm)
    for i in range(5):
        for j in range(5):
            v=matrix.iloc[i,j]
            left.text(j,i,('1' if i==j else f'{v:.3f}'.lstrip('0')),ha='center',va='center',fontsize=6.8,
                      color='white' if v>.66 else INK,fontweight='semibold' if i==j else 'normal')
    left.set(xticks=range(5),yticks=range(5),xticklabels=['1','2','3','4','5'],yticklabels=['1','2','3','4','5'],xlabel='Source',ylabel='Source')
    left.tick_params(length=0)
    for s in left.spines.values(): s.set_visible(False)
    left.set_title('(a)  Pairwise correlation',loc='left',fontsize=8.3,fontweight='semibold',pad=6)
    for idx,(label,color,mark,style) in enumerate([('A',TEAL,'o','-'),('B',RUST,'s','--'),('C',INK,'^',':')]):
        right.plot(lines.q,lines[f'BetP_{idx}'],color=color,marker=mark,ms=3.8,ls=style,label=label)
    right.set(xticks=[2,3,4,5],xlim=(1.83,5.17),ylim=(-.025,1.03),yticks=[0,.25,.50,.75,1],xlabel='Number of sources, $q$',ylabel='Pignistic probability')
    right.legend(ncol=3,loc='upper center',bbox_to_anchor=(.74,.63),fontsize=7.0,handlelength=.9,handletextpad=.3,columnspacing=.7)
    right.set_title('(b)  Support by target',loc='left',fontsize=8.3,fontweight='semibold',pad=6)
    tidy(right);save(fig,'fig2_five_sources')


def rotor():
    df=pd.read_csv(RESULTS/'rotor_paths.csv')
    fig,ax=plt.subplots(figsize=(4.78,2.62))
    fig.subplots_adjust(.126,.219,.964,.936)
    ax.axhspan(.75,.8,facecolor='#f7f0eb',zorder=-2)
    for name,color,style in [('RSAR',TEAL,'-'),('Tang',INK,'--')]:
        vals=df[(df.sensor==2)&(df.method==name)]
        ax.plot(vals.t,vals.mass_unbalance,ls=style,color=color,label='Tang et al. (2023)' if name=='Tang' else name,lw=1.9)
        ax.plot([1],vals.mass_unbalance.iloc[-1:],marker='o' if name=='RSAR' else 's',ms=4,color=color,clip_on=False)
    ax.axhline(.8,color=RUST,lw=.95,ls=(0,(1.2,2)))
    ax.text(.032,.7955,'Decision threshold  0.80',ha='left',va='top',color=RUST,fontsize=7.5)
    landmark=pd.read_csv(RESULTS/'rotor_landmarks.csv').set_index('method').loc['RSAR']
    point=(landmark.t,landmark.mass_unbalance)
    ax.plot(*point,'o',color=TEAL,ms=3.4)
    ax.annotate(f'Minimum ≈ {landmark.mass_unbalance:.5f}',xy=point,xytext=(.25,.827),fontsize=7.5,color=TEAL,
                arrowprops={'arrowstyle':'-','color':TEAL,'lw':.6},ha='left')
    ax.set(xlim=(0,1.02),ylim=(.767,.98),yticks=[.8,.85,.9,.95],xticks=np.arange(0,1.01,.2),
           xlabel='Fraction of source 2’s transferable mass on misalignment, $t$',ylabel='Fused mass on unbalance')
    ax.legend(loc='upper right',fontsize=8)
    tidy(ax);save(fig,'fig3_rotor')


def benchmark():
    data=pd.read_csv(RESULTS/'paired_intervals.csv')
    names=['Dempster','Arithmetic mean','Murphy','Deng','Han','Tang','Lu and Xiao','Xi (2n)','Huang and Deng']
    labels=['Dempster','Arithmetic mean','Murphy','Deng et al.','Han et al.','Tang et al. (2023)','Lu and Xiao','Xi et al.','Huang and Deng']
    fig,(a,b)=plt.subplots(1,2,figsize=(4.78,2.85),sharey=True)
    fig.subplots_adjust(.26,.19,.975,.855,wspace=.19)
    for ax,metric,sign,title in [(a,'accuracy_points',1,'(a)  Accuracy gain'),(b,'brier',-1,'(b)  Brier reduction')]:
        ax.axvline(0,lw=.8,color='#61727d',ls=':')
        for j,name in enumerate(names):
            row=data[(data.reference==name)&(data.metric==metric)].iloc[0]
            lo,hi=sorted([sign*row.lower,sign*row.upper]);v=sign*row.proposed_minus_reference
            ax.plot([lo,hi],[j,j],lw=1.2,color=TEAL);ax.plot(v,j,'o',ms=3.3,color=INK)
        ax.set_ylim(len(names)-.5,-.5)
        ax.set_yticks(range(len(names)),labels=labels)
        ax.set_title(title,fontsize=8.35,fontweight='semibold',loc='left',pad=6)
        ax.set_xlabel('Percentage points' if sign==1 else 'Brier score units')
        ax.spines[['top','right','left']].set_visible(False)
        ax.tick_params(axis='y',length=0,pad=3)
        ax.tick_params(axis='x',length=2.4,width=.6)
        ax.grid(axis='y',lw=.45,color='#e1e6e8');ax.set_axisbelow(True)
    a.set_xticks([-1,0,2,4]);b.set_xticks([0,.05,.10,.15],['0','.05','.10','.15'])
    save(fig,'fig4_labelled')


if __name__=='__main__':
    workflow();five();rotor();benchmark()
