"""Finite-frame reference implementation. A set is represented by its bit mask.

The order of hypotheses is A,B,C for the target cases and N,U,M,L for
the rotor. Output arrays are indexed by subset mask, including empty set 0.
"""
from pathlib import Path
import csv
import numpy as np


def embed(rows, focal_masks, frame_size):
    masses = np.zeros((len(rows), 2**frame_size))
    masses[:, focal_masks] = rows
    assert np.min(masses) >= 0 and np.allclose(masses.sum(axis=1), 1)
    return masses


FIVE = embed([[.41,.29,.30,0], [0,.90,.10,0], [.58,.07,0,.35],
              [.55,.10,0,.35], [.60,.10,.30,0]], [1,2,4,5], 3)
LIN = embed([[.50,.20,.30,0], [0,.80,.20,0], [.55,0,0,.45],
             [.50,.10,0,.40], [.60,.10,0,.30]], [1,2,4,5], 3)
ROTOR = embed([[.06,.68,.02,.04,.20], [.02,0,.79,.05,.14],
               [.02,.58,.16,.04,.20]], [1,2,4,8,15], 4)


def normalize(values):
    total = values.sum()
    return values / total if total > 0 else np.full(len(values), 1/len(values))


def jaccard(size):
    return np.array([[(a & b).bit_count() / (a | b).bit_count() if a|b else 0
                      for b in range(size)] for a in range(size)])


def betp(mass):
    size = mass.shape[-1]
    singles = [1 << k for k in range(size.bit_length()-1)]
    transform = np.array([[1/a.bit_count() if a & k else 0 for k in singles]
                          for a in range(size)])
    return mass @ transform


def combine(masses):
    size = masses.shape[1]
    pairs = np.bitwise_and.outer(np.arange(size), np.arange(size)).ravel()
    fused = masses[0]
    for source in masses[1:]:
        raw = np.bincount(pairs, weights=np.outer(fused,source).ravel(), minlength=size)
        raw[0] = 0
        if not raw.sum():
            raise ValueError("Total conflict in direct Dempster combination.")
        fused = raw / raw.sum()
    return fused


def repeated(pool, n):
    return combine(np.tile(pool,(n,1)))


def without_diagonal(matrix):
    off = matrix.copy()
    np.fill_diagonal(off, 0)
    return off


def network(masses):
    n = len(masses)
    if n < 2:
        raise ValueError("At least two sources are required.")
    gram = masses @ jaccard(masses.shape[1]) @ masses.T
    diag = gram.diagonal()
    corr = np.clip(gram/np.sqrt(np.outer(diag,diag)),0,1)
    np.fill_diagonal(corr,1)
    edges = without_diagonal(corr)
    ns = edges.sum(axis=1)
    shares = np.divide(edges,ns[None,:],out=np.zeros_like(edges),where=ns[None,:]>0)
    mu = shares.sum(axis=1)/(n-1)
    rho = ns/(n-1)
    return corr, ns, mu, normalize(ns*mu), rho


def adjust(masses,weights,retention):
    rho = np.broadcast_to(retention,(len(masses),))[:,None]
    return rho*masses + (1-rho)*(weights@masses)


def proposed(masses):
    if len(masses)==1:
        return masses[0].copy()
    _,_,_,weights,rho = network(masses)
    return combine(adjust(masses,weights,rho))


def huang_deng(masses):
    """Huang and Deng (2026), primary base-2 Deng entropy and Eqs. 11-15."""
    size = masses.shape[1]
    volume = np.array([max(1,2**a.bit_count()-1) for a in range(size)])
    entropy = -(masses*np.log2(np.where(masses>0,masses/volume,1))).sum(axis=1)
    credibility = 1/(1+np.exp(-entropy))
    discounted = masses*credibility[:,None]
    discounted[:,-1] += 1-credibility
    return combine(discounted)


def case_methods(masses):
    n,size = masses.shape
    _,ns,mu,weights,rho = network(masses)
    gram = masses @ jaccard(size) @ masses.T
    sq = gram.diagonal()
    distance = np.sqrt(np.maximum(0,(sq[:,None]+sq-2*gram)/2))
    wd = normalize(without_diagonal(1-distance).sum(axis=1))
    p = betp(masses)
    entropy = -(p*np.log2(np.where(p>0,p,1))).sum(axis=1)
    if np.min(entropy) <= 0:
        raise ValueError("Han's entropy adjustment needs a zero-entropy convention.")
    wh = normalize(wd*normalize(entropy)**(-(wd-1/n)))
    inner = p@p.T
    norms = inner.diagonal()
    btc = inner/(norms[:,None]+norms-inner)
    wb = normalize(without_diagonal(btc).sum(axis=1))
    single = embed([normalize((wb@p)**n)],[1<<k for k in range(p.shape[1])],p.shape[1])[0]
    abs_weights = normalize(ns**2)
    return {
        'Dempster':combine(masses),'Arithmetic mean':masses.mean(axis=0),
        'Murphy':repeated(masses.mean(axis=0),n),'Deng':repeated(wd@masses,n),
        'Han':repeated(wh@masses,n),'Tang':combine(adjust(masses,abs_weights,.5)),
        'Lu and Xiao':single,'Huang and Deng':huang_deng(masses),'RSAR':proposed(masses),
        'Uniform pool':combine(adjust(masses,np.full(n,1/n),rho)),
        'Strength pool':combine(adjust(masses,normalize(ns),rho)),
        'Squared-strength pool':combine(adjust(masses,abs_weights,rho)),
        'Relative loss, fixed retention':combine(adjust(masses,weights,.5))
    }


def write_rows(path,rows):
    with Path(path).open('w',newline='',encoding='utf-8') as out:
        writer = csv.DictWriter(out,fieldnames=list(dict.fromkeys(k for row in rows for k in row)))
        writer.writeheader()
        writer.writerows(rows)


def case_outputs(out):
    out.mkdir(exist_ok=True,parents=True)
    outputs, sources, entries = [],[],[]
    for label,masses,target in [('Five',FIVE,0),('Lin',LIN,0),('Rotor',ROTOR,1)]:
        for q in (range(2,6) if label=='Five' else [len(masses)]):
            batch = masses[:q]
            for method,m in case_methods(batch).items():
                prob = betp(m)
                row = dict(case=label,q=q,method=method,target_mass=m[1<<target],target_BetP=prob[target])
                row.update({f'mass_{k}':v for k,v in enumerate(m)})
                row.update({f'BetP_{k}':v for k,v in enumerate(prob)})
                outputs.append(row)
            corr,ns,mu,weights,rho = network(batch)
            mod = adjust(batch,weights,rho)
            for i in range(q):
                row = dict(case=label,q=q,source=i+1,strength=ns[i],mu=mu[i],weight=weights[i],
                           retention=rho[i],self_coefficient=rho[i]+(1-rho[i])*weights[i])
                row.update({f'adjusted_{k}':v for k,v in enumerate(mod[i])})
                sources.append(row)
                for j in range(q):
                    entries.append(dict(case=label,q=q,i=i+1,j=j+1,correlation=corr[i,j]))
    write_rows(out/'case_results.csv',outputs)
    write_rows(out/'source_coefficients.csv',sources)
    write_rows(out/'correlations.csv',entries)


if __name__=='__main__':
    case_outputs(Path(__file__).resolve().parent/'results')
