"""Repeated out-of-fold evaluation on four labelled datasets. Run python benchmark.py."""
from pathlib import Path
from itertools import product
import csv
import numpy as np
from scipy.special import softmax
from sklearn.datasets import load_iris, load_wine
from sklearn.model_selection import StratifiedKFold
from fusion import write_rows

RULES = ['Dempster','Arithmetic mean','Murphy','Deng','Han','Tang','Lu and Xiao',
         'Xi (2n)','Xi (n)','Huang and Deng','RSAR','Uniform pool','Strength pool','Squared-strength pool']
SEEDS = (42, 43, 44, 45, 46)
PROB_FLOOR = 1e-15


def unit_sum(a):
    total=a.sum(-1,keepdims=True)
    return np.divide(a,total,out=np.full_like(a,1/a.shape[-1]),where=total>0)


def normalize_columns_per_case(x):
    length=np.linalg.norm(x,axis=1,keepdims=True)
    return np.divide(x,length,out=np.zeros_like(x),where=length>0)


def seeds_dataset(return_X_y=True):
    data=np.loadtxt(Path(__file__).with_name('seeds.csv'),delimiter=',')
    assert data.shape==(210,8) and np.array_equal(np.unique(data[:,-1],return_counts=True)[1],[70,70,70])
    return data[:,:-1],data[:,-1].astype(int)-1


def penguins_dataset(return_X_y=True):
    # Keep the four continuous morphological measurements.
    with Path(__file__).with_name('penguins.csv').open() as f:
        rows=list(csv.DictReader(f))
    features=['bill_length_mm','bill_depth_mm','flipper_length_mm','body_mass_g']
    complete=[r for r in rows if all(r[key] not in ('','NA') for key in features)]
    X=np.asarray([[float(r[key]) for key in features] for r in complete])
    _,y=np.unique([r['species'] for r in complete],return_inverse=True)
    assert X.shape==(342,4)
    return X,y


def distribution(log_scores):
    return softmax(log_scores,axis=-1)


def gaussian_probabilities(X_train, y_train, X_test):
    """Fit one univariate Gaussian per feature and class, uniform class prior."""
    means=np.stack([X_train[y_train==k].mean(0) for k in range(3)],axis=-1)
    var=np.stack([X_train[y_train==k].var(0) for k in range(3)],axis=-1)
    variance_floor=np.maximum(X_train.var(0)*1e-9,np.finfo(float).tiny)
    var=np.maximum(var,variance_floor[:,None])
    log_density=-.5*(np.log(var)+(X_test[:,:,None]-means)**2/var)
    return unit_sum(np.maximum(distribution(log_density),PROB_FLOOR))


def fuse_many(p):
    """Specializations of the cited methods for strictly positive singleton inputs."""
    batch,n,k=p.shape
    eye=np.eye(n,dtype=bool)
    gram=p@p.transpose(0,2,1)
    sqnorm=np.diagonal(gram,axis1=1,axis2=2)
    cos=gram/np.sqrt(sqnorm[:,:,None]*sqnorm[:,None,:])
    edges=np.where(eye,0,np.clip(cos,0,1))
    strength=edges.sum(2)
    mu=np.divide(edges,strength[:,None,:],out=np.zeros_like(edges),where=strength[:,None,:]>0).sum(2)/(n-1)
    rho=strength/(n-1)
    weights=unit_sum(strength*mu)

    mean=lambda w: np.einsum('bi,bik->bk',w,p)
    pooled=mean(weights)
    averaged=p.mean(1)
    reps=lambda m: distribution(n*np.log(m))
    ds=lambda rows: distribution(np.log(rows).sum(1))
    avg_adjusted=rho[:,:,None]*p+(1-rho[:,:,None])*pooled[:,None,:]
    tang_pool=mean(unit_sum(strength**2))
    sqdist=np.maximum(sqnorm[:,:,None]+sqnorm[:,None,:]-2*gram,0)
    distance=np.where(eye,0,np.sqrt(sqdist/2))
    wd=unit_sum(np.where(eye,0,1-distance).sum(2))
    entropy=-(p*np.log(p)).sum(2)
    en=unit_sum(entropy)
    han_weights=unit_sum(wd*en**(-(wd-1/n)))
    btc=gram/(sqnorm[:,:,None]+sqnorm[:,None,:]-gram)
    lu_weights=unit_sum(np.where(eye,0,btc).sum(2))

    # Xi et al., Eqs (9),(11),(25)-(35). The Zhou entropy becomes
    # Shannon entropy on singleton-only BPAs. Row scaling cancels the log base.
    kl=np.maximum((p*np.log(p)).sum(2)[:,:,None]-p@np.log(p).transpose(0,2,1),0)
    xi_total=sum(normalize_columns_per_case(row) for row in (distance.sum(2),np.where(eye,0,kl).sum(2),entropy))
    pair_total=xi_total[:,:,None]+xi_total[:,None,:]
    importance=np.divide(xi_total[:,None,:],pair_total,out=np.full_like(pair_total,.5),where=pair_total>0)
    xi_weights=distribution(2*n*np.log(importance.sum(2)))
    # Huang and Deng use base-2 Deng entropy. On singletons this is Shannon entropy in bits.
    credibility = 1/(1+np.exp(-entropy/np.log(2)))
    uncommitted = 1-credibility
    ignorance = uncommitted.prod(axis=1)[:,None]
    conjunctive = (credibility[:,:,None]*p+uncommitted[:,:,None]).prod(axis=1)-ignorance
    huang_betp = unit_sum(np.maximum(conjunctive,0)+ignorance/k)
    xi_alt = distribution(n*np.log(importance.sum(2)))
    def substitute(w):
        return ds(rho[:,:,None]*p+(1-rho[:,:,None])*mean(w)[:,None,:])
    results = [ds(p),averaged,reps(averaged),reps(mean(wd)),reps(mean(han_weights)),
               ds((p+tang_pool[:,None,:])/2),reps(mean(lu_weights)),reps(mean(xi_weights)),
               reps(mean(xi_alt)),huang_betp,ds(avg_adjusted),substitute(np.ones_like(weights)/n),
               substitute(unit_sum(strength)),substitute(unit_sum(strength**2))]
    for result in results:
        assert np.isfinite(result).all() and result.min()>=0 and np.allclose(result.sum(-1),1)
    return np.stack(results,axis=1)


def run(out):
    out.mkdir(parents=True, exist_ok=True)
    summaries, by_seed, inference = [], [], []
    for dataset,load in [('Iris',load_iris),('Wine',load_wine),('Seeds',seeds_dataset),('Penguins',penguins_dataset)]:
        X,y=load(return_X_y=True);n,features=X.shape
        indicator=np.eye(3)[y][:,None,:]
        for setting in ['clean','one_source_label_swap']:
            # If a source misidentifies classes, cycle its output labels. Include every
            # feature and BOTH non-identity circular directions. These versions of an
            # observation remain together, never counted as independent subjects.
            out_by_seed=[]
            for seed in SEEDS:
                acc=np.zeros((n,len(RULES)));brier=np.zeros_like(acc)
                for train,test in StratifiedKFold(5,shuffle=True,random_state=seed).split(X,y):
                    x=gaussian_probabilities(X[train],y[train],X[test])
                    scenarios=[(None,0)] if setting=='clean' else product(range(features),(1,-1))
                    for col,direction in scenarios:
                        modified=x.copy()
                        if col is not None: modified[:,col,:]=np.roll(x[:,col,:],direction,axis=-1)
                        pred=fuse_many(modified)
                        truth=indicator[test]
                        acc[test]+=(pred.argmax(-1)==y[test,None])
                        brier[test]+=((pred-truth)**2).sum(-1)
                trials=1 if setting=='clean' else 2*features
                acc/=trials;brier/=trials
                out_by_seed.append(np.stack([acc,brier],axis=-1))
                for j,rule in enumerate(RULES):
                    by_seed.append(dict(dataset=dataset,setting=setting,seed=seed,method=rule,
                                        accuracy=acc[:,j].mean(),brier=brier[:,j].mean()))
            perf=np.mean(out_by_seed,axis=0)
            for j,rule in enumerate(RULES):
                summaries.append(dict(dataset=dataset,setting=setting,method=rule,observations=n,
                                      accuracy=perf[:,j,0].mean(),brier=perf[:,j,1].mean()))
            for i in range(n):
                for j,rule in enumerate(RULES):
                    inference.append(dict(dataset=dataset,setting=setting,row_index=i,method=rule,
                                          accuracy=perf[i,j,0],brier=perf[i,j,1]))
    write_rows(out/'classification.csv',summaries)
    write_rows(out/'by_split_seed.csv',by_seed)
    write_rows(out/'by_observation.csv',inference)


if __name__=='__main__':
    run(Path(__file__).resolve().parent/'results')
